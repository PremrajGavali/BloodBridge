import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const donationFormSchema = z.object({
  hospitalId: z.coerce.number({ required_error: "Please select a hospital" }),
  donationType: z.string().min(1, { message: "Please select a donation type" }),
  date: z.date({ required_error: "Please select a date" })
    .refine(date => date > new Date(), {
      message: "Appointment date must be in the future"
    }),
});

type DonationFormValues = z.infer<typeof donationFormSchema>;

export default function DonationForm() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isDateOpen, setIsDateOpen] = useState(false);
  
  const { data: hospitals, isLoading: isLoadingHospitals } = useQuery({
    queryKey: ["/api/hospitals"],
  });

  const appointmentMutation = useMutation({
    mutationFn: async (values: DonationFormValues) => {
      const res = await apiRequest("POST", "/api/appointments", {
        ...values,
        userId: user?.id,
        status: "scheduled"
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Appointment scheduled",
        description: "Your blood donation appointment has been scheduled",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Scheduling failed",
        description: error.message || "Failed to schedule appointment",
        variant: "destructive",
      });
    },
  });

  const form = useForm<DonationFormValues>({
    resolver: zodResolver(donationFormSchema),
    defaultValues: {
      donationType: "",
    },
  });

  function onSubmit(values: DonationFormValues) {
    appointmentMutation.mutate(values);
  }

  return (
    <Card className="max-w-xl mx-auto shadow-md">
      <CardHeader>
        <CardTitle>Schedule Blood Donation</CardTitle>
        <CardDescription>
          Book an appointment to donate blood at one of our partner hospitals.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="hospitalId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Hospital</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value?.toString()}
                    disabled={isLoadingHospitals}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a hospital" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {hospitals && hospitals.map((hospital: any) => (
                        <SelectItem key={hospital.id} value={hospital.id.toString()}>
                          {hospital.hospitalName || `Hospital #${hospital.id}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose the hospital where you'd like to donate blood.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="donationType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type of Donation</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a donation type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="whole_blood">Whole Blood</SelectItem>
                      <SelectItem value="platelets">Platelets</SelectItem>
                      <SelectItem value="plasma">Plasma</SelectItem>
                      <SelectItem value="power_red">Power Red</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Select the type of donation you'd like to make.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Appointment Date</FormLabel>
                  <Popover open={isDateOpen} onOpenChange={setIsDateOpen}>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className="w-full pl-3 text-left font-normal"
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => {
                          field.onChange(date);
                          setIsDateOpen(false);
                        }}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>
                    Choose a date for your donation appointment. Only future dates are available.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-primary text-white hover:bg-red-700"
              disabled={appointmentMutation.isPending}
            >
              {appointmentMutation.isPending ? "Scheduling..." : "Schedule Donation"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
