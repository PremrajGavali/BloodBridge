import { useState } from "react";
import { Button } from "@/components/ui/button";

type PortalSelectorProps = {
  activePortal: "user" | "hospital";
  onChange: (portal: "user" | "hospital") => void;
};

export default function PortalSelector({ 
  activePortal, 
  onChange 
}: PortalSelectorProps) {
  return (
    <div className="bg-white border-b">
      <div className="container mx-auto flex justify-center py-3">
        <div className="flex rounded-md overflow-hidden">
          <Button
            onClick={() => onChange("user")}
            className={`px-6 py-2 text-sm font-medium ${
              activePortal === "user"
                ? "bg-primary text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            } rounded-r-none`}
            variant={activePortal === "user" ? "default" : "secondary"}
          >
            User Portal
          </Button>
          <Button
            onClick={() => onChange("hospital")}
            className={`px-6 py-2 text-sm font-medium ${
              activePortal === "hospital"
                ? "bg-primary text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            } rounded-l-none`}
            variant={activePortal === "hospital" ? "default" : "secondary"}
          >
            Hospital Portal
          </Button>
        </div>
      </div>
    </div>
  );
}
