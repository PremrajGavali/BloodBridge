import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Building } from "lucide-react";

type HospitalDashboardProps = {
  className?: string;
  onUpdateInventory: () => void;
  onIssueAlert: () => void;
};

export default function HospitalDashboard({ 
  className, 
  onUpdateInventory, 
  onIssueAlert 
}: HospitalDashboardProps) {
  const { user } = useAuth();
  
  return (
    <Card className={`bg-white rounded-lg shadow-md ${className}`}>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center text-white text-2xl font-bold mr-4">
              {user?.hospitalName ? user.hospitalName.substring(0, 2).toUpperCase() : "H"}
            </div>
            <div>
              <h2 className="text-2xl font-bold">{user?.hospitalName || "Hospital"}</h2>
              <p className="text-gray-600">{user?.hospitalType || "Medical Center"}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button 
              onClick={onUpdateInventory}
              className="px-4 py-2 bg-primary text-white hover:bg-red-700"
            >
              Update Inventory
            </Button>
            <Button 
              onClick={onIssueAlert}
              className="px-4 py-2 bg-accent text-white hover:bg-blue-700"
            >
              Issue Alert
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
