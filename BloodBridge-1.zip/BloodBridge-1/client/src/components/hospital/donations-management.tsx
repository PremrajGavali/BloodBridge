import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Donation, User, Appointment } from "@shared/schema";
import { Calendar, FileText, Download } from "lucide-react";

type DonationEntry = Appointment & {
  user: User;
};

export default function DonationsManagement() {
  const { toast } = useToast();
  
  // Mock upcoming donations for demonstration
  const { data: appointments, isLoading: isLoadingAppointments } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Fetch donations that need certificates
  const { data: donations, isLoading: isLoadingDonations } = useQuery<Donation[]>({
    queryKey: ["/api/donations"],
  });

  const checkInMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/appointments/${id}`, { status: "checked-in" });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Check-in completed",
        description: "Donor has been checked in",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Check-in failed",
        description: error.message || "Failed to check in donor",
        variant: "destructive",
      });
    },
  });

  const rescheduleMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/appointments/${id}`, { status: "rescheduled" });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Appointment rescheduled",
        description: "The donation appointment has been marked for rescheduling",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Reschedule failed",
        description: error.message || "Failed to reschedule appointment",
        variant: "destructive",
      });
    },
  });

  const generateCertificateMutation = useMutation({
    mutationFn: async (donationId: number) => {
      const res = await apiRequest("POST", "/api/certificates", { donationId });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donations"] });
      toast({
        title: "Certificate generated",
        description: "Donation certificate has been successfully generated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Certificate generation failed",
        description: error.message || "Failed to generate certificate",
        variant: "destructive",
      });
    },
  });

  // Filter completed donations that need certificates
  const pendingCertificates = donations?.filter(
    donation => donation.status === "completed" && !donation.certificateIssued
  ) || [];

  // Filter scheduled appointments
  const upcomingDonations = appointments?.filter(
    appointment => appointment.status === "scheduled"
  ) || [];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      {/* Upcoming Donations */}
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardHeader className="border-b border-gray-200 px-6 py-4">
          <CardTitle className="text-lg font-medium text-gray-900">Upcoming Donations</CardTitle>
        </CardHeader>
        <CardContent className="divide-y divide-gray-200">
          {isLoadingAppointments || isLoadingUsers ? (
            <>
              <Skeleton className="h-16 my-2" />
              <Skeleton className="h-16 my-2" />
              <Skeleton className="h-16 my-2" />
            </>
          ) : upcomingDonations.length > 0 ? (
            upcomingDonations.map((appointment) => (
              <div key={appointment.id} className="px-6 py-4 flex items-center">
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {/* In a real app, we would join with user data */}
                    Donor #{appointment.userId}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(appointment.date).toLocaleDateString()} • {new Date(appointment.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </p>
                </div>
                <div className="ml-auto flex space-x-2">
                  <Button 
                    variant="outline"
                    size="sm"
                    className="px-3 py-1 bg-gray-100 text-gray-700 text-xs hover:bg-gray-200"
                    onClick={() => rescheduleMutation.mutate(appointment.id)}
                    disabled={rescheduleMutation.isPending}
                  >
                    Reschedule
                  </Button>
                  <Button 
                    size="sm"
                    className="px-3 py-1 bg-accent text-white text-xs hover:bg-blue-700"
                    onClick={() => checkInMutation.mutate(appointment.id)}
                    disabled={checkInMutation.isPending}
                  >
                    Check-in
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500">No upcoming donations</p>
            </div>
          )}
        </CardContent>
        <CardFooter className="px-6 py-3 bg-gray-50">
          <Button variant="link" className="text-sm font-medium text-accent hover:text-blue-700">
            View all appointments →
          </Button>
        </CardFooter>
      </Card>
      
      {/* Certificate Management */}
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardHeader className="border-b border-gray-200 px-6 py-4">
          <CardTitle className="text-lg font-medium text-gray-900">Certificate Management</CardTitle>
        </CardHeader>
        <CardContent className="divide-y divide-gray-200">
          {isLoadingDonations ? (
            <>
              <Skeleton className="h-16 my-2" />
              <Skeleton className="h-16 my-2" />
              <Skeleton className="h-16 my-2" />
            </>
          ) : pendingCertificates.length > 0 ? (
            pendingCertificates.map((donation) => (
              <div key={donation.id} className="px-6 py-4 flex items-center">
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    Donor #{donation.userId}
                  </p>
                  <p className="text-xs text-gray-500">
                    Donation on {new Date(donation.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="ml-auto">
                  <Button 
                    size="sm"
                    className="px-3 py-1 bg-primary text-white text-xs hover:bg-red-700 flex items-center gap-1"
                    onClick={() => generateCertificateMutation.mutate(donation.id)}
                    disabled={generateCertificateMutation.isPending}
                  >
                    <FileText size={12} />
                    Generate Certificate
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500">No pending certificates</p>
            </div>
          )}
        </CardContent>
        <CardFooter className="px-6 py-3 bg-gray-50">
          <Button variant="link" className="text-sm font-medium text-accent hover:text-blue-700">
            Manage all certificates →
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
