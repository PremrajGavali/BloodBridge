import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Check, AlertCircle } from "lucide-react";
import { BloodInventory as BloodInventoryType } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

const updateInventorySchema = z.object({
  bloodGroup: z.string().min(1, "Blood group is required"),
  units: z.string().transform(val => parseInt(val, 10)).refine(val => !isNaN(val) && val >= 0, "Units must be a positive number"),
});

type FormValues = z.infer<typeof updateInventorySchema>;

export default function BloodInventory() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  
  const { data: inventory, isLoading } = useQuery<BloodInventoryType[]>({
    queryKey: ["/api/blood-inventory"],
    enabled: !!user?.isHospital,
  });

  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/blood-inventory", { 
        bloodGroup: values.bloodGroup,
        units: values.units
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-inventory"] });
      setIsUpdateDialogOpen(false);
      toast({
        title: "Inventory updated",
        description: "Blood inventory has been successfully updated",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update inventory",
        variant: "destructive",
      });
    },
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(updateInventorySchema),
    defaultValues: {
      bloodGroup: "",
      units: "",
    },
  });

  const onSubmit = (values: FormValues) => {
    updateMutation.mutate(values);
  };

  // Get inventory level percentage for a blood group
  const getInventoryLevel = (bloodGroup: string) => {
    if (!inventory) return 0;
    const groupInventory = inventory.find(item => item.bloodGroup === bloodGroup);
    if (!groupInventory) return 0;
    
    // Assume 20 units is 100%
    return Math.min(100, (groupInventory.units / 20) * 100);
  };

  // Get status color based on inventory level
  const getStatusColor = (level: number) => {
    if (level >= 60) return "bg-success";
    if (level >= 30) return "bg-warning";
    return "bg-primary";
  };

  // Get units for a blood group
  const getUnits = (bloodGroup: string) => {
    if (!inventory) return 0;
    const groupInventory = inventory.find(item => item.bloodGroup === bloodGroup);
    return groupInventory?.units || 0;
  };

  return (
    <>
      <Card className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <CardHeader className="border-b border-gray-200 px-6 py-4">
          <CardTitle className="text-lg font-medium text-gray-900">Blood Inventory Status</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 text-center">
            {isLoading ? (
              <>
                {[...Array(8)].map((_, i) => (
                  <Skeleton key={i} className="h-28 rounded-lg" />
                ))}
              </>
            ) : (
              bloodGroups.map(group => (
                <div key={group} className="bg-gray-100 p-4 rounded-lg">
                  <p className="text-xl font-bold text-primary">{group}</p>
                  <p className="text-2xl font-bold">{getUnits(group)}</p>
                  <p className="text-xs text-gray-600">Units</p>
                  <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <Progress
                      value={getInventoryLevel(group)}
                      className={`h-full ${getStatusColor(getInventoryLevel(group))}`}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Update Blood Inventory</DialogTitle>
            <DialogDescription>
              Enter the current units available for a specific blood group.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="bloodGroup"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Blood Group</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select blood group" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {bloodGroups.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="units"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Units Available</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Enter number of units"
                        min="0"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsUpdateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={updateMutation.isPending}
                >
                  {updateMutation.isPending ? "Updating..." : "Update Inventory"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}
