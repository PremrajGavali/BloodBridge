import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Donation, BloodRequest, User } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react";

export default function Analytics() {
  const { data: donations, isLoading: isLoadingDonations } = useQuery<Donation[]>({
    queryKey: ["/api/donations"],
  });
  
  const { data: requests, isLoading: isLoadingRequests } = useQuery<BloodRequest[]>({
    queryKey: ["/api/blood-requests"],
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Calculate analytics data
  const getTotalDonations = () => {
    if (!donations) return 0;
    return donations.filter(d => d.status === "completed").length;
  };

  const getTotalRequests = () => {
    if (!requests) return 0;
    return requests.length;
  };

  const getNewDonors = () => {
    if (!users) return 0;
    // In a real app, we'd filter by date
    // Here we're just showing total users who aren't hospitals
    return users.filter(u => !u.isHospital).length;
  };

  // Mock percentage changes
  const donationsChange = 12;
  const requestsChange = 3;
  const donorsChange = 18;

  // Mock chart data
  const chartData = [
    { name: 'Jan', donations: 35, requests: 29 },
    { name: 'Feb', donations: 42, requests: 31 },
    { name: 'Mar', donations: 38, requests: 35 },
    { name: 'Apr', donations: 45, requests: 38 },
    { name: 'May', donations: 50, requests: 40 },
    { name: 'Jun', donations: 55, requests: 42 },
  ];

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden">
      <CardHeader className="border-b border-gray-200 px-6 py-4">
        <CardTitle className="text-lg font-medium text-gray-900">Monthly Analytics</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoadingDonations || isLoadingRequests || isLoadingUsers ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-64 w-full" />
          </>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Total Donations</p>
                <p className="text-2xl font-bold text-gray-900">{getTotalDonations()}</p>
                <p className={`text-xs ${donationsChange >= 0 ? 'text-success' : 'text-primary'} flex items-center`}>
                  {donationsChange >= 0 ? <ArrowUpIcon size={12} className="mr-1" /> : <ArrowDownIcon size={12} className="mr-1" />}
                  {Math.abs(donationsChange)}% from last month
                </p>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Blood Requests</p>
                <p className="text-2xl font-bold text-gray-900">{getTotalRequests()}</p>
                <p className={`text-xs ${requestsChange >= 0 ? 'text-success' : 'text-primary'} flex items-center`}>
                  {requestsChange >= 0 ? <ArrowUpIcon size={12} className="mr-1" /> : <ArrowDownIcon size={12} className="mr-1" />}
                  {Math.abs(requestsChange)}% from last month
                </p>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">New Donors</p>
                <p className="text-2xl font-bold text-gray-900">{getNewDonors()}</p>
                <p className={`text-xs ${donorsChange >= 0 ? 'text-success' : 'text-primary'} flex items-center`}>
                  {donorsChange >= 0 ? <ArrowUpIcon size={12} className="mr-1" /> : <ArrowDownIcon size={12} className="mr-1" />}
                  {Math.abs(donorsChange)}% from last month
                </p>
              </div>
            </div>
            
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="donations" name="Donations" fill="#E31837" />
                  <Bar dataKey="requests" name="Requests" fill="#0066CC" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
