import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download } from "lucide-react";
import { Donation } from "@shared/schema";

export default function DonationHistory() {
  const { data: donations, isLoading } = useQuery<Donation[]>({
    queryKey: ["/api/donations"],
  });

  if (isLoading) {
    return (
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardHeader className="border-b border-gray-200 px-6 py-4">
          <CardTitle className="text-lg font-medium text-gray-900">Donation History</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Skeleton className="h-64 rounded-none" />
        </CardContent>
      </Card>
    );
  }

  // Sort donations by date, newest first
  const sortedDonations = donations 
    ? [...donations].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden">
      <CardHeader className="border-b border-gray-200 px-6 py-4">
        <CardTitle className="text-lg font-medium text-gray-900">Donation History</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</TableHead>
                <TableHead className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</TableHead>
                <TableHead className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</TableHead>
                <TableHead className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</TableHead>
                <TableHead className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Certificate</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="bg-white divide-y divide-gray-200">
              {sortedDonations.length > 0 ? (
                sortedDonations.map((donation) => (
                  <TableRow key={donation.id}>
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(donation.date).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {donation.locationName}
                    </TableCell>
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {donation.donationType}
                    </TableCell>
                    <TableCell className="px-6 py-4 whitespace-nowrap">
                      <span 
                        className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          donation.status === "completed" 
                            ? "bg-green-100 text-success" 
                            : donation.status === "pending" 
                            ? "bg-yellow-100 text-warning"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {donation.status.charAt(0).toUpperCase() + donation.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {donation.certificateIssued ? (
                        <Button variant="link" className="text-accent hover:text-blue-700 flex items-center gap-1 p-0">
                          <Download size={14} />
                          Download
                        </Button>
                      ) : (
                        <span className="text-gray-400">Not Available</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                    No donation history available
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
