import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

type BloodAlert = {
  id: number;
  hospitalId: number;
  hospitalName: string;
  bloodGroup: string;
  message: string;
  distance: string;
};

type UserAlertProps = {
  alert: BloodAlert;
  onRespond: (alertId: number) => void;
  className?: string;
};

export default function UserAlert({ alert, onRespond, className }: UserAlertProps) {
  return (
    <Alert className={`bg-red-100 border-l-4 border-primary p-4 mb-8 rounded-md ${className}`}>
      <div className="flex">
        <AlertTriangle className="h-5 w-5 text-primary" />
        <div className="ml-3 flex-1">
          <AlertTitle className="text-sm font-medium text-primary">
            URGENT: Blood Needed
          </AlertTitle>
          <AlertDescription className="mt-2 text-sm text-red-700">
            <p>{alert.hospitalName} requires {alert.bloodGroup} blood for emergency surgery. Located {alert.distance} from you.</p>
          </AlertDescription>
          <div className="mt-4">
            <div className="-mx-2 -my-1.5 flex">
              <Button 
                onClick={() => onRespond(alert.id)}
                variant="outline"
                className="bg-red-100 px-2 py-1.5 rounded-md text-sm font-medium text-primary hover:bg-red-200"
              >
                Respond
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Alert>
  );
}
