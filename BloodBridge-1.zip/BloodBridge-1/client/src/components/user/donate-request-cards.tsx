import { Link } from "wouter";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, PlusCircle } from "lucide-react";

export default function DonateRequestCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Donation Card */}
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary text-white mb-4">
            <PlusCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Donate Blood</h3>
          <p className="text-gray-600 mb-4">Schedule your next blood donation at a nearby center or hospital.</p>
          <Button asChild className="w-full bg-primary text-white hover:bg-red-700">
            <Link href="/donate-blood">Schedule Donation</Link>
          </Button>
        </CardContent>
      </Card>
      
      {/* Request Card */}
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-md bg-accent text-white mb-4">
            <Calendar className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Request Blood</h3>
          <p className="text-gray-600 mb-4">Submit a blood request for yourself or someone else in need.</p>
          <Button asChild className="w-full bg-accent text-white hover:bg-blue-700">
            <Link href="/request-blood">Submit Request</Link>
          </Button>
        </CardContent>
      </Card>
      
      {/* Find Center Card */}
      <Card className="bg-white rounded-lg shadow-md overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-md bg-success text-white mb-4">
            <MapPin className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Find Blood Centers</h3>
          <p className="text-gray-600 mb-4">Locate nearby blood donation centers and hospitals.</p>
          <Button asChild className="w-full bg-success text-white hover:bg-green-700">
            <Link href="/find-centers">Find Centers</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
