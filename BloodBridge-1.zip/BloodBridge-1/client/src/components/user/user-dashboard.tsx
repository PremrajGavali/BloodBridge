import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

type UserDashboardProps = {
  className?: string;
};

export default function UserDashboard({ className }: UserDashboardProps) {
  const { user } = useAuth();
  
  const { data: donations, isLoading: isLoadingDonations } = useQuery({
    queryKey: ["/api/donations"],
    enabled: !!user,
  });

  // Placeholder function to calculate eligible date
  const getNextEligibleDate = () => {
    if (!donations || donations.length === 0) return "Eligible now";
    
    // Sort donations by date, newest first
    const sortedDonations = [...donations].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    
    const lastDonation = sortedDonations[0];
    const lastDonationDate = new Date(lastDonation.date);
    const eligibleDate = new Date(lastDonationDate);
    eligibleDate.setDate(eligibleDate.getDate() + 56); // 56 days = 8 weeks
    
    const today = new Date();
    if (eligibleDate <= today) return "Eligible now";
    
    const diffTime = Math.abs(eligibleDate.getTime() - today.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return `${diffDays} days`;
  };

  const formatLastDonation = () => {
    if (!donations || donations.length === 0) return "Never donated";
    
    const sortedDonations = [...donations].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    
    const lastDonation = sortedDonations[0];
    const lastDonationDate = new Date(lastDonation.date);
    
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lastDonationDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 30) return `${diffDays} days ago`;
    if (diffDays < 60) return "1 month ago";
    return `${Math.floor(diffDays / 30)} months ago`;
  };

  // Estimated lives saved (each donation can save up to 3 lives)
  const livesSaved = donations ? donations.length * 3 : 0;

  return (
    <Card className={`bg-white rounded-lg shadow-md ${className}`}>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center mb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold mr-4">
              {user?.fullName ? `${user.fullName.charAt(0)}${user.fullName.split(' ')[1]?.charAt(0) || ''}` : user?.username.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <h2 className="text-2xl font-bold">{user?.fullName || user?.username}</h2>
              <p className="text-gray-600">Blood Group: {user?.bloodGroup || "Unknown"}</p>
            </div>
          </div>
          <div className="md:ml-auto">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-success">
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
              </svg>
              Verified Donor
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
          {isLoadingDonations ? (
            <>
              <Skeleton className="h-24 bg-gray-200 rounded-lg" />
              <Skeleton className="h-24 bg-gray-200 rounded-lg" />
              <Skeleton className="h-24 bg-gray-200 rounded-lg" />
              <Skeleton className="h-24 bg-gray-200 rounded-lg" />
            </>
          ) : (
            <>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-3xl font-bold text-primary">{donations ? donations.length : 0}</p>
                <p className="text-gray-600">Donations</p>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-3xl font-bold text-accent">{formatLastDonation()}</p>
                <p className="text-gray-600">Last Donation</p>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-3xl font-bold text-success">{getNextEligibleDate()}</p>
                <p className="text-gray-600">Next Eligible</p>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="text-3xl font-bold text-warning">{livesSaved}</p>
                <p className="text-gray-600">Lives Saved</p>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
