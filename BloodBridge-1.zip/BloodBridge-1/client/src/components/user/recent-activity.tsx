import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Download } from "lucide-react";
import { Donation } from "@shared/schema";

export default function RecentActivity() {
  const { data: donations, isLoading } = useQuery<Donation[]>({
    queryKey: ["/api/donations"],
  });

  if (isLoading) {
    return (
      <Card className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <CardHeader className="border-b border-gray-200 px-6 py-4">
          <CardTitle className="text-lg font-medium text-gray-900">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent className="divide-y divide-gray-200">
          <Skeleton className="h-16 my-4" />
          <Skeleton className="h-16 my-4" />
          <Skeleton className="h-16 my-4" />
        </CardContent>
      </Card>
    );
  }

  // Sort donations by date, newest first
  const sortedDonations = donations 
    ? [...donations].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 3)
    : [];

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
      <CardHeader className="border-b border-gray-200 px-6 py-4">
        <CardTitle className="text-lg font-medium text-gray-900">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="divide-y divide-gray-200">
        {sortedDonations.length > 0 ? (
          sortedDonations.map((donation) => (
            <div key={donation.id} className="px-6 py-4">
              <div className="flex items-center">
                <div className="w-2 h-2 rounded-full bg-success mr-3"></div>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {donation.certificateIssued ? "Donation Certificate Issued" : "Blood Donation Completed"}
                  </p>
                  <p className="text-sm text-gray-500">
                    {donation.locationName} - {new Date(donation.date).toLocaleDateString()}
                  </p>
                </div>
                <div className="ml-auto">
                  {donation.certificateIssued ? (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-accent hover:text-blue-700 flex items-center gap-1"
                    >
                      <Download size={14} />
                      Download
                    </Button>
                  ) : (
                    <span className="text-success text-sm font-medium">Complete</span>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="px-6 py-8 text-center">
            <p className="text-gray-500">No recent activity</p>
          </div>
        )}
      </CardContent>
      <CardFooter className="px-6 py-3 bg-gray-50">
        <Button variant="link" className="text-sm font-medium text-accent hover:text-blue-700">
          View all activity →
        </Button>
      </CardFooter>
    </Card>
  );
}
