import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Menu, LogOut, User, Heart, Building, BarChart3, Droplet } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Droplet className="w-8 h-8 text-primary" />
            <Link href="/">
              <a className="text-2xl font-bold text-primary">LifeFlow</a>
            </Link>
          </div>
          
          {/* Navigation Links */}
          <nav className="hidden md:flex space-x-8 text-gray-700">
            <Link href="/">
              <a className={`font-medium hover:text-primary transition duration-150 ${location === '/' ? 'text-primary' : ''}`}>
                Home
              </a>
            </Link>
            <Link href="/about">
              <a className={`font-medium hover:text-primary transition duration-150 ${location === '/about' ? 'text-primary' : ''}`}>
                About
              </a>
            </Link>
            <Link href="/find-centers">
              <a className={`font-medium hover:text-primary transition duration-150 ${location === '/find-centers' ? 'text-primary' : ''}`}>
                Find Centers
              </a>
            </Link>
            <Link href="/faq">
              <a className={`font-medium hover:text-primary transition duration-150 ${location === '/faq' ? 'text-primary' : ''}`}>
                FAQ
              </a>
            </Link>
            <Link href="/contact">
              <a className={`font-medium hover:text-primary transition duration-150 ${location === '/contact' ? 'text-primary' : ''}`}>
                Contact
              </a>
            </Link>
          </nav>
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="hidden md:flex items-center space-x-2">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold">
                        {user.fullName ? `${user.fullName.charAt(0)}${user.fullName.split(' ')[1]?.charAt(0) || ''}` : user.username.substring(0, 2).toUpperCase()}
                      </div>
                      <span>{user.fullName || user.username}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="cursor-pointer flex items-center gap-2">
                      <User size={16} /> Profile
                    </DropdownMenuItem>
                    {user.isHospital ? (
                      <DropdownMenuItem className="cursor-pointer flex items-center gap-2">
                        <BarChart3 size={16} /> Dashboard
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem className="cursor-pointer flex items-center gap-2">
                        <Heart size={16} /> My Donations
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={handleLogout} className="cursor-pointer flex items-center gap-2 text-primary hover:text-primary">
                      <LogOut size={16} /> Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button asChild variant="default" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-red-700">
                <Link href="/auth">Login / Register</Link>
              </Button>
            )}
            
            {/* Mobile Menu Toggle */}
            <Button variant="ghost" className="md:hidden p-2 text-gray-600 hover:bg-gray-100" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              <Link href="/">
                <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary">Home</a>
              </Link>
              <Link href="/about">
                <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary">About</a>
              </Link>
              <Link href="/find-centers">
                <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary">Find Centers</a>
              </Link>
              <Link href="/faq">
                <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary">FAQ</a>
              </Link>
              <Link href="/contact">
                <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary">Contact</a>
              </Link>
              {user && (
                <>
                  <div className="border-t border-gray-200 pt-4 mt-2">
                    <Link href="/profile">
                      <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary flex items-center">
                        <User size={16} className="mr-2" /> Profile
                      </a>
                    </Link>
                    {user.isHospital ? (
                      <Link href="/dashboard">
                        <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary flex items-center mt-4">
                          <Building size={16} className="mr-2" /> Hospital Dashboard
                        </a>
                      </Link>
                    ) : (
                      <Link href="/donations">
                        <a onClick={closeMenu} className="font-medium text-gray-700 hover:text-primary flex items-center mt-4">
                          <Heart size={16} className="mr-2" /> My Donations
                        </a>
                      </Link>
                    )}
                    <button 
                      onClick={() => { handleLogout(); closeMenu(); }} 
                      className="font-medium text-primary hover:text-red-700 flex items-center mt-4 w-full text-left"
                    >
                      <LogOut size={16} className="mr-2" /> Log out
                    </button>
                  </div>
                </>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
