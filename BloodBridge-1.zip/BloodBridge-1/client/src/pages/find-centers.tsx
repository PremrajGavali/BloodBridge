import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Building, Phone, MapPin, Clock, ExternalLink } from "lucide-react";

// Mock hospital data for demonstration purposes
const mockHospitals = [
  {
    id: 1,
    name: "Central Hospital",
    address: "123 Main Street, Downtown, City",
    phone: "(555) 123-4567",
    type: "Regional Blood Center",
    hours: "Mon-Fri: 8:00 AM - 8:00 PM, Sat-Sun: 9:00 AM - 5:00 PM",
    distance: "1.2 miles"
  },
  {
    id: 2,
    name: "Memorial Medical Center",
    address: "456 Park Avenue, Midtown, City",
    phone: "(555) 234-5678",
    type: "Community Hospital",
    hours: "Mon-Fri: 7:00 AM - 9:00 PM, Sat-Sun: 8:00 AM - 6:00 PM",
    distance: "2.5 miles"
  },
  {
    id: 3,
    name: "City General Hospital",
    address: "789 Broadway, Uptown, City",
    phone: "(555) 345-6789",
    type: "General Hospital",
    hours: "24/7",
    distance: "3.8 miles"
  },
  {
    id: 4,
    name: "Red Cross Blood Center",
    address: "101 Blood Drive, Westside, City",
    phone: "(555) 456-7890",
    type: "Blood Bank",
    hours: "Mon-Fri: 9:00 AM - 7:00 PM, Sat: 10:00 AM - 4:00 PM, Sun: Closed",
    distance: "4.3 miles"
  }
];

export default function FindCentersPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [mapLoaded, setMapLoaded] = useState(false);
  
  const { data: hospitals, isLoading } = useQuery({
    queryKey: ["/api/hospitals"],
  });
  
  // Filter hospitals based on search query
  const filteredHospitals = searchQuery 
    ? mockHospitals.filter(hospital => 
        hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hospital.address.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : mockHospitals;
  
  // Simulate map loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setMapLoaded(true);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-1">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-2">Find Blood Donation Centers</h1>
          <p className="text-gray-600 text-center mb-8">Locate hospitals and blood banks near you</p>
          
          <div className="flex mb-6">
            <Input
              type="text"
              placeholder="Search by name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 mr-2"
            />
            <Button className="bg-primary text-white">
              Search
            </Button>
          </div>
          
          <Tabs defaultValue="list">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="list">List View</TabsTrigger>
              <TabsTrigger value="map">Map View</TabsTrigger>
            </TabsList>
            
            <TabsContent value="list">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {isLoading ? (
                  Array(4).fill(0).map((_, index) => (
                    <Skeleton key={index} className="h-64 w-full" />
                  ))
                ) : (
                  filteredHospitals.map(hospital => (
                    <Card key={hospital.id} className="shadow-md">
                      <CardHeader className="pb-2">
                        <CardTitle className="flex items-center gap-2">
                          <Building className="h-5 w-5 text-primary" />
                          {hospital.name}
                        </CardTitle>
                        <CardDescription>{hospital.type}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-gray-500 mt-1 shrink-0" />
                          <p className="text-sm text-gray-600">{hospital.address}</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <Phone className="h-4 w-4 text-gray-500 mt-1 shrink-0" />
                          <p className="text-sm text-gray-600">{hospital.phone}</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <Clock className="h-4 w-4 text-gray-500 mt-1 shrink-0" />
                          <p className="text-sm text-gray-600">{hospital.hours}</p>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <span className="text-sm text-gray-500">{hospital.distance} away</span>
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <ExternalLink className="h-4 w-4" />
                          Directions
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="map">
              <Card className="shadow-md">
                <CardContent className="p-0 h-[500px] relative">
                  {mapLoaded ? (
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                      <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d50000!2d-74.0060!3d40.7128!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sus!4v1596542588000!5m2!1sen!2sus" 
                        width="100%" 
                        height="100%" 
                        style={{ border: 0 }} 
                        allowFullScreen={false} 
                        loading="lazy"
                        title="Blood donation centers map"
                      ></iframe>
                    </div>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <Skeleton className="h-full w-full" />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          <div className="mt-12 bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">About Our Blood Donation Centers</h2>
            <p className="text-gray-700 mb-4">
              Our network includes hospitals, community health centers, and dedicated blood banks. All locations adhere to strict safety protocols and are staffed by trained healthcare professionals.
            </p>
            <h3 className="text-lg font-bold mt-6 mb-2">What to Bring</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-700">
              <li>Photo ID (driver's license, passport, etc.)</li>
              <li>List of medications you're currently taking</li>
              <li>Contact information for your primary care physician</li>
            </ul>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
