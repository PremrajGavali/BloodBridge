import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import RequestForm from "@/components/forms/request-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function RequestBloodPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      setLocation("/auth");
    }
  }, [user, setLocation]);
  
  if (!user) {
    return null; // Will redirect to login
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-1">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-6">Request Blood</h1>
          
          <Card className="mb-8 border-warning">
            <CardHeader className="pb-2 flex flex-row items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <CardTitle className="text-warning">Emergency Guidelines</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-700">
                <p className="mb-2"><strong>Please note:</strong> This form is for planned blood requirements.</p>
                <p>For immediate life-threatening emergencies, please contact the nearest hospital emergency room directly or call emergency services.</p>
              </CardDescription>
            </CardContent>
          </Card>
          
          <div className="grid md:grid-cols-3 gap-8 mb-10">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-accent text-lg flex items-center">
                  <span className="bg-accent/10 p-2 rounded-full mr-2">1</span>
                  Submit Request
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Complete the blood request form with all required information.
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-accent text-lg flex items-center">
                  <span className="bg-accent/10 p-2 rounded-full mr-2">2</span>
                  Hospital Review
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Hospital staff will review your request and check inventory.
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-accent text-lg flex items-center">
                  <span className="bg-accent/10 p-2 rounded-full mr-2">3</span>
                  Fulfillment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Upon approval, blood will be prepared for the requested date.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
          
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6 text-center">Blood Request Form</h2>
            <RequestForm />
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-bold mb-3">Request Priority</h3>
              <p className="text-gray-700 mb-4">
                <strong>Urgent:</strong> Required within 24-48 hours for immediate medical needs.
              </p>
              <p className="text-gray-700 mb-2">
                <strong>Standard:</strong> Required for scheduled procedures or treatments within a week or more.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-bold mb-3">Blood Compatibility</h3>
              <p className="text-gray-700 mb-4">
                Please ensure you request the correct blood type. In emergency situations, O- blood can be used for all patients, but specific matching is always preferred when time allows.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
