import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import PortalSelector from "@/components/portal-selector";
import UserDashboard from "@/components/user/user-dashboard";
import UserAlert from "@/components/user/user-alert";
import DonateRequestCards from "@/components/user/donate-request-cards";
import RecentActivity from "@/components/user/recent-activity";
import DonationHistory from "@/components/user/donation-history";
import HospitalDashboard from "@/components/hospital/hospital-dashboard";
import BloodInventory from "@/components/hospital/blood-inventory";
import PendingRequests from "@/components/hospital/pending-requests";
import DonationsManagement from "@/components/hospital/donations-management";
import Analytics from "@/components/hospital/analytics";
import { Alert } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

type ActivePortal = "user" | "hospital";

export default function HomePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Default to user portal unless user is hospital
  const [activePortal, setActivePortal] = useState<ActivePortal>(
    user?.isHospital ? "hospital" : "user"
  );
  
  // Mock alert data for demonstration
  const mockAlert = {
    id: 1,
    hospitalId: 1,
    hospitalName: "Central Hospital",
    bloodGroup: "O+",
    message: "Blood needed for emergency surgery",
    distance: "3.2 miles"
  };
  
  const { data: alerts } = useQuery<Alert[]>({
    queryKey: ["/api/alerts", "Downtown"],
    enabled: activePortal === "user",
  });
  
  const handleRespondToAlert = (alertId: number) => {
    // In a real app, this would navigate to a specific response form
    // or create a donation appointment
    toast({
      title: "Alert response received",
      description: "Thank you for responding! You'll be contacted with further details.",
    });
  };
  
  const handleUpdateInventory = () => {
    // This would normally open a modal, but for simplicity we'll rely on 
    // the functionality built into the BloodInventory component
    toast({
      title: "Update your inventory",
      description: "Use the blood inventory section below to update blood group levels",
    });
  };
  
  const handleIssueAlert = () => {
    toast({
      title: "Alert feature",
      description: "This feature would allow issuing emergency blood requests to donors in your area",
    });
  };
  
  // Switch to hospital portal if user is a hospital
  useEffect(() => {
    if (user?.isHospital) {
      setActivePortal("hospital");
    }
  }, [user]);
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <PortalSelector activePortal={activePortal} onChange={setActivePortal} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-red-800 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="text-4xl font-bold leading-tight mb-4">Save Lives with Your Donation</h2>
              <p className="text-lg mb-8">Your blood donation can save up to 3 lives. Join our network of donors and hospitals to make a difference today.</p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <button 
                  onClick={() => setLocation("/donate-blood")}
                  className="px-6 py-3 bg-white text-primary font-bold rounded-md hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
                >
                  Donate Blood
                </button>
                <button 
                  onClick={() => setLocation("/request-blood")}
                  className="px-6 py-3 bg-transparent border-2 border-white text-white font-bold rounded-md hover:bg-white hover:text-primary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
                >
                  Request Blood
                </button>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1615461066841-6116e61058f4?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Blood donation process" 
                className="rounded-lg shadow-xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
      
      <main className="container mx-auto px-4 py-8">
        {activePortal === "user" ? (
          <>
            {/* User Portal Dashboard */}
            <UserDashboard className="mb-8" />
            
            {/* Alert Section - Only show if there are active alerts */}
            {alerts && alerts.length > 0 ? (
              <UserAlert 
                alert={mockAlert} 
                onRespond={handleRespondToAlert} 
                className="mb-8"
              />
            ) : null}
            
            {/* Action Cards */}
            <DonateRequestCards />
            
            {/* Recent Activity */}
            <RecentActivity />
            
            {/* Donation History */}
            <DonationHistory />
          </>
        ) : (
          <>
            {/* Hospital Portal Dashboard */}
            <HospitalDashboard 
              className="mb-8" 
              onUpdateInventory={handleUpdateInventory}
              onIssueAlert={handleIssueAlert}
            />
            
            {/* Blood Inventory */}
            <BloodInventory />
            
            {/* Pending Requests */}
            <PendingRequests />
            
            {/* Donation Management */}
            <DonationsManagement />
            
            {/* Analytics */}
            <Analytics />
          </>
        )}
      </main>
      
      <Footer />
    </div>
  );
}
