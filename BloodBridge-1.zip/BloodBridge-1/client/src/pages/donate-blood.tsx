import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import DonationForm from "@/components/forms/donation-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function DonateBloodPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      setLocation("/auth");
    }
  }, [user, setLocation]);
  
  if (!user) {
    return null; // Will redirect to login
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-1">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-6">Donate Blood</h1>
          
          <div className="grid md:grid-cols-3 gap-8 mb-10">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-success text-lg flex items-center">
                  <span className="bg-success/10 p-2 rounded-full mr-2">1</span>
                  Schedule
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Schedule an appointment at your preferred hospital or donation center.
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-success text-lg flex items-center">
                  <span className="bg-success/10 p-2 rounded-full mr-2">2</span>
                  Donate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Complete your donation at the scheduled time and location.
                </CardDescription>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-success text-lg flex items-center">
                  <span className="bg-success/10 p-2 rounded-full mr-2">3</span>
                  Save Lives
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Your donation can help save up to three lives in need.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md mb-10">
            <h2 className="text-xl font-bold mb-4">Important Information</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>You must be at least 18 years old to donate blood</li>
              <li>You should weigh at least 110 pounds (50 kg)</li>
              <li>Be in good general health and feeling well</li>
              <li>Wait at least 56 days between whole blood donations</li>
              <li>Bring a valid ID on the day of your appointment</li>
              <li>Eat well and stay hydrated before your appointment</li>
            </ul>
          </div>
          
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6 text-center">Schedule Your Donation</h2>
            <DonationForm />
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-bold mb-3">What to Expect</h3>
              <p className="text-gray-700 mb-4">
                The donation process takes about an hour from start to finish, with the actual donation taking around 8-10 minutes. After donation, you'll be provided with refreshments and asked to rest for about 15 minutes.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-bold mb-3">After Donating</h3>
              <p className="text-gray-700 mb-4">
                After donating, drink plenty of fluids, avoid strenuous physical activity for the rest of the day, and keep the bandage on for at least four hours. Your body will replace the fluid lost during donation within 24 hours.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
