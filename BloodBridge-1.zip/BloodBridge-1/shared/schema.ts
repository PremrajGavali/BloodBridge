import { pgTable, text, serial, integer, boolean, timestamp, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number").notNull(),
  bloodGroup: text("blood_group").notNull(),
  address: text("address").notNull(),
  isHospital: boolean("is_hospital").default(false).notNull(),
  hospitalName: text("hospital_name"),
  hospitalType: text("hospital_type"),
});

export const donations = pgTable("donations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  locationName: text("location_name").notNull(),
  donationType: text("donation_type").notNull(),
  amount: integer("amount").notNull(),
  date: timestamp("date").notNull(),
  status: text("status").notNull(),
  certificateIssued: boolean("certificate_issued").default(false).notNull(),
});

export const bloodRequests = pgTable("blood_requests", {
  id: serial("id").primaryKey(),
  patientName: text("patient_name").notNull(),
  bloodGroup: text("blood_group").notNull(),
  units: integer("units").notNull(),
  hospitalId: integer("hospital_id").references(() => users.id),
  requesterId: integer("requester_id").references(() => users.id),
  priority: text("priority").notNull(),
  department: text("department"),
  date: timestamp("date").notNull(),
  status: text("status").notNull(),
});

export const bloodInventory = pgTable("blood_inventory", {
  id: serial("id").primaryKey(),
  hospitalId: integer("hospital_id").notNull().references(() => users.id),
  bloodGroup: text("blood_group").notNull(),
  units: integer("units").notNull(),
  lastUpdated: timestamp("last_updated").notNull(),
});

export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  hospitalId: integer("hospital_id").notNull().references(() => users.id),
  bloodGroup: text("blood_group").notNull(),
  message: text("message").notNull(),
  district: text("district").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").notNull(),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  hospitalId: integer("hospital_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  status: text("status").notNull(),
});

// Schemas for inserting data
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  phoneNumber: true,
  bloodGroup: true,
  address: true,
  isHospital: true,
  hospitalName: true,
  hospitalType: true,
});

export const insertDonationSchema = createInsertSchema(donations).pick({
  userId: true,
  locationName: true,
  donationType: true,
  amount: true,
  date: true,
  status: true,
  certificateIssued: true,
});

export const insertBloodRequestSchema = createInsertSchema(bloodRequests).pick({
  patientName: true,
  bloodGroup: true,
  units: true,
  hospitalId: true,
  requesterId: true,
  priority: true,
  department: true,
  date: true,
  status: true,
});

export const insertBloodInventorySchema = createInsertSchema(bloodInventory).pick({
  hospitalId: true,
  bloodGroup: true,
  units: true,
  lastUpdated: true,
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  hospitalId: true,
  bloodGroup: true,
  message: true,
  district: true,
  isActive: true,
  createdAt: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).pick({
  userId: true,
  hospitalId: true,
  date: true,
  status: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Donation = typeof donations.$inferSelect;
export type InsertDonation = z.infer<typeof insertDonationSchema>;

export type BloodRequest = typeof bloodRequests.$inferSelect;
export type InsertBloodRequest = z.infer<typeof insertBloodRequestSchema>;

export type BloodInventory = typeof bloodInventory.$inferSelect;
export type InsertBloodInventory = z.infer<typeof insertBloodInventorySchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
