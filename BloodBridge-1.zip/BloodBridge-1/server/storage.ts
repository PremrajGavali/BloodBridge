import { 
  users, type User, type InsertUser,
  donations, type Donation, type InsertDonation,
  bloodRequests, type BloodRequest, type InsertBloodRequest,
  bloodInventory, type BloodInventory, type InsertBloodInventory,
  alerts, type Alert, type InsertAlert,
  appointments, type Appointment, type InsertAppointment
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  
  // Hospital methods
  getHospitals(): Promise<User[]>;
  getHospital(id: number): Promise<User | undefined>;
  
  // Donation methods
  getDonation(id: number): Promise<Donation | undefined>;
  getUserDonations(userId: number): Promise<Donation[]>;
  createDonation(donation: InsertDonation): Promise<Donation>;
  updateDonation(id: number, donationData: Partial<Donation>): Promise<Donation | undefined>;
  
  // Blood request methods
  getBloodRequest(id: number): Promise<BloodRequest | undefined>;
  getUserBloodRequests(userId: number): Promise<BloodRequest[]>;
  getHospitalBloodRequests(hospitalId: number): Promise<BloodRequest[]>;
  createBloodRequest(request: InsertBloodRequest): Promise<BloodRequest>;
  updateBloodRequest(id: number, requestData: Partial<BloodRequest>): Promise<BloodRequest | undefined>;
  
  // Blood inventory methods
  getBloodInventory(hospitalId: number, bloodGroup: string): Promise<BloodInventory | undefined>;
  getHospitalInventory(hospitalId: number): Promise<BloodInventory[]>;
  createBloodInventory(inventory: InsertBloodInventory): Promise<BloodInventory>;
  updateBloodInventory(id: number, inventoryData: Partial<BloodInventory>): Promise<BloodInventory | undefined>;
  
  // Alert methods
  getActiveAlerts(district: string): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: number, alertData: Partial<Alert>): Promise<Alert | undefined>;
  
  // Appointment methods
  getAppointment(id: number): Promise<Appointment | undefined>;
  getUserAppointments(userId: number): Promise<Appointment[]>;
  getHospitalAppointments(hospitalId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private donations: Map<number, Donation>;
  private bloodRequests: Map<number, BloodRequest>;
  private bloodInventories: Map<number, BloodInventory>;
  private alerts: Map<number, Alert>;
  private appointments: Map<number, Appointment>;
  private currentIds: {
    users: number;
    donations: number;
    bloodRequests: number;
    bloodInventories: number;
    alerts: number;
    appointments: number;
  };
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.donations = new Map();
    this.bloodRequests = new Map();
    this.bloodInventories = new Map();
    this.alerts = new Map();
    this.appointments = new Map();
    this.currentIds = {
      users: 1,
      donations: 1,
      bloodRequests: 1,
      bloodInventories: 1,
      alerts: 1,
      appointments: 1
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Hospital methods
  async getHospitals(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isHospital);
  }

  async getHospital(id: number): Promise<User | undefined> {
    const hospital = await this.getUser(id);
    return hospital?.isHospital ? hospital : undefined;
  }

  // Donation methods
  async getDonation(id: number): Promise<Donation | undefined> {
    return this.donations.get(id);
  }

  async getUserDonations(userId: number): Promise<Donation[]> {
    return Array.from(this.donations.values()).filter(
      donation => donation.userId === userId
    );
  }

  async createDonation(insertDonation: InsertDonation): Promise<Donation> {
    const id = this.currentIds.donations++;
    const donation: Donation = { ...insertDonation, id };
    this.donations.set(id, donation);
    return donation;
  }

  async updateDonation(id: number, donationData: Partial<Donation>): Promise<Donation | undefined> {
    const donation = this.donations.get(id);
    if (!donation) return undefined;
    
    const updatedDonation = { ...donation, ...donationData };
    this.donations.set(id, updatedDonation);
    return updatedDonation;
  }

  // Blood request methods
  async getBloodRequest(id: number): Promise<BloodRequest | undefined> {
    return this.bloodRequests.get(id);
  }

  async getUserBloodRequests(userId: number): Promise<BloodRequest[]> {
    return Array.from(this.bloodRequests.values()).filter(
      request => request.requesterId === userId
    );
  }

  async getHospitalBloodRequests(hospitalId: number): Promise<BloodRequest[]> {
    return Array.from(this.bloodRequests.values()).filter(
      request => request.hospitalId === hospitalId
    );
  }

  async createBloodRequest(insertRequest: InsertBloodRequest): Promise<BloodRequest> {
    const id = this.currentIds.bloodRequests++;
    const request: BloodRequest = { ...insertRequest, id };
    this.bloodRequests.set(id, request);
    return request;
  }

  async updateBloodRequest(id: number, requestData: Partial<BloodRequest>): Promise<BloodRequest | undefined> {
    const request = this.bloodRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { ...request, ...requestData };
    this.bloodRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  // Blood inventory methods
  async getBloodInventory(hospitalId: number, bloodGroup: string): Promise<BloodInventory | undefined> {
    return Array.from(this.bloodInventories.values()).find(
      inventory => inventory.hospitalId === hospitalId && inventory.bloodGroup === bloodGroup
    );
  }

  async getHospitalInventory(hospitalId: number): Promise<BloodInventory[]> {
    return Array.from(this.bloodInventories.values()).filter(
      inventory => inventory.hospitalId === hospitalId
    );
  }

  async createBloodInventory(insertInventory: InsertBloodInventory): Promise<BloodInventory> {
    const id = this.currentIds.bloodInventories++;
    const inventory: BloodInventory = { ...insertInventory, id };
    this.bloodInventories.set(id, inventory);
    return inventory;
  }

  async updateBloodInventory(id: number, inventoryData: Partial<BloodInventory>): Promise<BloodInventory | undefined> {
    const inventory = this.bloodInventories.get(id);
    if (!inventory) return undefined;
    
    const updatedInventory = { ...inventory, ...inventoryData };
    this.bloodInventories.set(id, updatedInventory);
    return updatedInventory;
  }

  // Alert methods
  async getActiveAlerts(district: string): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter(
      alert => alert.district === district && alert.isActive
    );
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = this.currentIds.alerts++;
    const alert: Alert = { ...insertAlert, id };
    this.alerts.set(id, alert);
    return alert;
  }

  async updateAlert(id: number, alertData: Partial<Alert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updatedAlert = { ...alert, ...alertData };
    this.alerts.set(id, updatedAlert);
    return updatedAlert;
  }

  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async getUserAppointments(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      appointment => appointment.userId === userId
    );
  }

  async getHospitalAppointments(hospitalId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      appointment => appointment.hospitalId === hospitalId
    );
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.currentIds.appointments++;
    const appointment: Appointment = { ...insertAppointment, id };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }
}

export const storage = new MemStorage();
