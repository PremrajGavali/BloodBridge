import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertDonationSchema, 
  insertBloodRequestSchema, 
  insertBloodInventorySchema,
  insertAlertSchema,
  insertAppointmentSchema
} from "@shared/schema";
import { z } from "zod";

function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

function isHospital(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated() && req.user.isHospital) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Hospital access required" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Hospitals API
  app.get("/api/hospitals", async (req, res) => {
    try {
      const hospitals = await storage.getHospitals();
      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

  app.get("/api/hospitals/:id", async (req, res) => {
    try {
      const hospital = await storage.getHospital(parseInt(req.params.id));
      if (!hospital) {
        return res.status(404).json({ message: "Hospital not found" });
      }
      res.json(hospital);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospital" });
    }
  });

  // Donations API
  app.get("/api/donations", isAuthenticated, async (req, res) => {
    try {
      const donations = await storage.getUserDonations(req.user.id);
      res.json(donations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donations" });
    }
  });

  app.post("/api/donations", isAuthenticated, async (req, res) => {
    try {
      const donationData = insertDonationSchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date),
        status: "pending"
      });
      const donation = await storage.createDonation(donationData);
      res.status(201).json(donation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid donation data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create donation" });
    }
  });

  app.get("/api/donations/:id", isAuthenticated, async (req, res) => {
    try {
      const donation = await storage.getDonation(parseInt(req.params.id));
      if (!donation) {
        return res.status(404).json({ message: "Donation not found" });
      }
      
      // Only allow access to the user's own donations or hospital staff
      if (donation.userId !== req.user.id && !req.user.isHospital) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(donation);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donation" });
    }
  });

  app.patch("/api/donations/:id", isHospital, async (req, res) => {
    try {
      const donationId = parseInt(req.params.id);
      const donation = await storage.getDonation(donationId);
      
      if (!donation) {
        return res.status(404).json({ message: "Donation not found" });
      }
      
      const updatedDonation = await storage.updateDonation(donationId, req.body);
      res.json(updatedDonation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update donation" });
    }
  });

  // Blood Requests API
  app.get("/api/blood-requests", isAuthenticated, async (req, res) => {
    try {
      let requests;
      if (req.user.isHospital) {
        requests = await storage.getHospitalBloodRequests(req.user.id);
      } else {
        requests = await storage.getUserBloodRequests(req.user.id);
      }
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blood requests" });
    }
  });

  app.post("/api/blood-requests", isAuthenticated, async (req, res) => {
    try {
      const requestData = insertBloodRequestSchema.parse({
        ...req.body,
        requesterId: req.user.id,
        date: new Date(req.body.date),
        status: "pending"
      });
      
      const request = await storage.createBloodRequest(requestData);
      res.status(201).json(request);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create blood request" });
    }
  });

  app.patch("/api/blood-requests/:id", isHospital, async (req, res) => {
    try {
      const requestId = parseInt(req.params.id);
      const request = await storage.getBloodRequest(requestId);
      
      if (!request) {
        return res.status(404).json({ message: "Blood request not found" });
      }
      
      // Only the assigned hospital can update the request
      if (request.hospitalId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedRequest = await storage.updateBloodRequest(requestId, req.body);
      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: "Failed to update blood request" });
    }
  });

  // Blood Inventory API
  app.get("/api/blood-inventory", isHospital, async (req, res) => {
    try {
      const inventory = await storage.getHospitalInventory(req.user.id);
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blood inventory" });
    }
  });

  app.post("/api/blood-inventory", isHospital, async (req, res) => {
    try {
      const inventoryData = insertBloodInventorySchema.parse({
        ...req.body,
        hospitalId: req.user.id,
        lastUpdated: new Date()
      });
      
      // Check if inventory for this blood group already exists
      const existingInventory = await storage.getBloodInventory(req.user.id, req.body.bloodGroup);
      
      if (existingInventory) {
        // Update existing inventory
        const updatedInventory = await storage.updateBloodInventory(
          existingInventory.id, 
          { units: req.body.units, lastUpdated: new Date() }
        );
        return res.json(updatedInventory);
      }
      
      // Create new inventory entry
      const inventory = await storage.createBloodInventory(inventoryData);
      res.status(201).json(inventory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid inventory data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update blood inventory" });
    }
  });

  // Alerts API
  app.get("/api/alerts", async (req, res) => {
    try {
      const district = req.query.district as string;
      if (!district) {
        return res.status(400).json({ message: "District parameter is required" });
      }
      
      const alerts = await storage.getActiveAlerts(district);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post("/api/alerts", isHospital, async (req, res) => {
    try {
      const alertData = insertAlertSchema.parse({
        ...req.body,
        hospitalId: req.user.id,
        isActive: true,
        createdAt: new Date()
      });
      
      const alert = await storage.createAlert(alertData);
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid alert data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create alert" });
    }
  });

  app.patch("/api/alerts/:id", isHospital, async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      const alert = await storage.updateAlert(alertId, req.body);
      
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: "Failed to update alert" });
    }
  });

  // Appointments API
  app.get("/api/appointments", isAuthenticated, async (req, res) => {
    try {
      let appointments;
      if (req.user.isHospital) {
        appointments = await storage.getHospitalAppointments(req.user.id);
      } else {
        appointments = await storage.getUserAppointments(req.user.id);
      }
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.post("/api/appointments", isAuthenticated, async (req, res) => {
    try {
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId: req.user.id,
        date: new Date(req.body.date),
        status: "scheduled"
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid appointment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  app.patch("/api/appointments/:id", isAuthenticated, async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const appointment = await storage.getAppointment(appointmentId);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Only allow updates by the user or the hospital
      if (appointment.userId !== req.user.id && appointment.hospitalId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const updatedAppointment = await storage.updateAppointment(appointmentId, req.body);
      res.json(updatedAppointment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  // Certificate generation
  app.post("/api/certificates", isHospital, async (req, res) => {
    try {
      const { donationId } = req.body;
      
      if (!donationId) {
        return res.status(400).json({ message: "Donation ID is required" });
      }
      
      const donation = await storage.getDonation(donationId);
      
      if (!donation) {
        return res.status(404).json({ message: "Donation not found" });
      }
      
      // Update donation to mark certificate as issued
      const updatedDonation = await storage.updateDonation(donationId, { certificateIssued: true });
      
      res.json({ success: true, donation: updatedDonation });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate certificate" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
